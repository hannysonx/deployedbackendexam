USE [BackendExam]
GO

/****** Object:  StoredProcedure [dbo].[SP_SchoolPersonCity]    Script Date: 2/6/2019 10:43:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_SchoolPersonCity]
	@fname VARCHAR(50),
	@lname VARCHAR(50),
	@schoolname VARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT P.Firstname, P.Lastname, C.CityName, S.SchoolName 
	FROM Person AS P
	INNER JOIN City AS C
	ON P.CityID = C.ID
	INNER JOIN School AS S
	ON P.SchoolID = S.ID
	WHERE (P.Firstname LIKE '%'+@fname+'%' OR P.Lastname LIKE '%'+@lname+'%')
	AND C.Country = 'Philippines'
	AND S.SchoolName LIKE '%' + @schoolname + '%'
	AND P.IsActive = 1
	AND S.IsActive = 1
	AND C.IsActive = 1
	ORDER BY P.Lastname, P.Firstname


END
GO

